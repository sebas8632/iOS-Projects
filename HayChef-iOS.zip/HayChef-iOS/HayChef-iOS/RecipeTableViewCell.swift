//
//  RecipeTableViewCell.swift
//  HayChef-iOS
//
//  Created by sebastian on 18/01/17.
//  Copyright © 2017 nhvm. All rights reserved.
//

import UIKit


/*
 Class that it containt all about recipeCell.
 */
class RecipeTableViewCell: UITableViewCell {

    
    //Variables
    
    @IBOutlet var recipeImageView: UIImageView!
    @IBOutlet var recipeNameLabel: UILabel!
    @IBOutlet var recipeTimeLabel: UILabel!
    @IBOutlet var recipeDifficultyLabel: UILabel!
    @IBOutlet var recipePortionsLabel: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
