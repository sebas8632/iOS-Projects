//
//  DetailRecipeViewController.swift
//  HayChef-iOS
//
//  Created by sebastian on 21/01/17.
//  Copyright © 2017 nhvm. All rights reserved.
//

import UIKit

class DetailRecipeViewController: UIViewController {

    var recipe : Recipe!
    
    @IBOutlet var detailRecipeImage: UIImageView!
    @IBOutlet var tableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        detailRecipeImage.image = self.recipe.image
        
        self.tableView.estimatedRowHeight = 44.0
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        self.tableView.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.90)
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        self.tableView.separatorColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1)

        navigationItem.title = self.recipe.name!
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


// MARK: - UITableViewDataSource


extension DetailRecipeViewController : UITableViewDataSource{
 
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return 4
        case 1:
            return self.recipe.ingredients.count
        case 2:
            return self.recipe.steps.count
        
        
        default:
            return 0
        }
    }
    
    
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        if indexPath.section == 0 {
            
            let cellID : String = "generalInfoCell"
            
            let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! DetailGeneralInfoTableViewCell
            
            switch indexPath.row {
           
            case 0:
                cell.keyLabel.text = "Nombre: "
                cell.valueLabel.text = self.recipe.name!

            case 1:
                cell.keyLabel.text = "Tiempo: "
                cell.valueLabel.text = "\(self.recipe.time!) Minutos"

            case 2:
                cell.keyLabel.text = "Dificultad: "

                switch self.recipe.difficulty {
               
                case 1:
                    cell.valueLabel.text = "Muy Bajo"
                    
                case 2:
                    cell.valueLabel.text = "Bajo"
                    
                case 3:
                    cell.valueLabel.text  = "Medio"
                    
                case 4:
                    cell.valueLabel.text  = "Medio Alto"
                    
                case 5:
                    cell.valueLabel.text  = "Alto"

                default:
                    cell.valueLabel.text = ""
                }
                
            case 3:
                
                cell.keyLabel.text = "Porciones: "
                cell.valueLabel.text = "\(self.recipe.portion!)"

                
            default:
                break
            }
            return cell
        }
        else if indexPath.section == 1{
            
            let cellID : String = "ingredientCell"
            
            let cell2 = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! IngredientTableViewCell
            
            
            
            cell2.ingredientLabel.text = self.recipe.ingredients[indexPath.row]
            
            
            return cell2
        }
        else{
            
            let cellID : String = "stepCell"
            
            let cell3 = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as!
                StepTableViewCell
            
            cell3.stepImage.image = self.recipe.steps[indexPath.row].1
            cell3.stepLabel.text = self.recipe.steps[indexPath.row].0
            
            return cell3
            
        }
        
    }
    
    
    
}

// MARK: - UITableViewDelegate

extension DetailRecipeViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        var title : String
        
        switch section {
        case 0:
            title = "Información General"
        case 1:
            title = "Ingredientes"
        case 2:
            title = "Pasos"
        default:
            title = ""
        }
        return title
    }
    
    
}

