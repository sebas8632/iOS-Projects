//
//  Recipe.swift
//  HayChef-iOS
//
//  Created by sebastian on 18/01/17.
//  Copyright © 2017 nhvm. All rights reserved.
//

import Foundation
import UIKit

class Recipe: NSObject {
    
    //Variable Declaration
    
    var name : String!
    var image : UIImage!
    var time : Int!
    var difficulty : Int!
    var portion : Int!
    var ingredients : [String]
    var steps : [(String,UIImage)]
    
    
    
    
    /*
        Function to initializer the Recipe object.
    */
    
    init(name: String, image: UIImage, time: Int, difficulty: Int, portion: Int, ingredients: [String], steps: [(String,UIImage)]) {
        
        self.name = name
        self.image = image
        self.time = time
        self.difficulty = difficulty
        self.portion = portion
        self.ingredients = ingredients
        self.steps = steps
        
    }
    
}
