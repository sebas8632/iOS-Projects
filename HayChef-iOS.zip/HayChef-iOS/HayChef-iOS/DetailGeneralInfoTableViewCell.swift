//
//  DetailGeneralInfoTableViewCell.swift
//  HayChef-iOS
//
//  Created by sebastian on 21/01/17.
//  Copyright © 2017 nhvm. All rights reserved.
//

import UIKit

class DetailGeneralInfoTableViewCell: UITableViewCell {

    
    @IBOutlet var keyLabel: UILabel!
    @IBOutlet var valueLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
