//
//  ViewController.swift
//  HayChef-iOS
//
//  Created by sebastian on 17/01/17.
//  Copyright © 2017 nhvm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    /*
     Esta vista es la encargada del login, la cual conecta los datos de logeo con la vista.
    */
    
    //Variables from main.storyboard
    
    @IBOutlet var usernameTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var logInButton: UIButton!
    @IBOutlet var joinUsButton: UIButton!
    
    
    //Variables
    
    var recipes : [Recipe]! = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.navigationController?.isNavigationBarHidden = true
        
        
        //Code to textField.borderColor to black.
        
        usernameTextField.layer.cornerRadius = 8.0
        usernameTextField.layer.masksToBounds = true
        usernameTextField.layer.borderColor = UIColor.black.cgColor
        usernameTextField.layer.borderWidth = 0.4
        
        passwordTextField.layer.cornerRadius = 8.0
        passwordTextField.layer.masksToBounds = true
        passwordTextField.layer.borderColor = UIColor.black.cgColor
        passwordTextField.layer.borderWidth = 0.4
        
        //Color of buttons
        
        self.logInButton.backgroundColor = UIColor(colorLiteralRed: 233.0/255.0, green: 75.0/255.0, blue: 74.0/255.0, alpha: 1.0)
            
        self.joinUsButton.backgroundColor = UIColor(colorLiteralRed: 242.0/255.0, green: 143.0/255.0, blue: 23.0/255.0, alpha: 1.0)
        
        //Here, start to create recipes
        
        var recipe : Recipe!
        
        recipe = Recipe(name: "Mil Hojas de Crema y Mango",
                        image: #imageLiteral(resourceName: "milHojasMango"),
                        time: 60,
                        difficulty: 3,
                        portion: 6,
                        ingredients: ["1 pieza de rebanadas de mango en almíbar en lata.",
                                      "3 piezas de hojaldre paquetes mililitros de leche",
                                      "100 gramos de azúcar glass para decorar",
                                      "200 gramos de crema para batir",
                                      "225 gramos de harina de maíz",
                                      "8 piezas de yema de huevo",
                                      "1 pieza de vaina de vainilla",
                                      "100 gramos de mantequilla",
                                      "40 gramos de pistache picados",
                                      "40 gramos de almendra tostada y en trozo"],
                        steps: [("Precalienta el horno a 180°C", #imageLiteral(resourceName: "recipe")),
                                ("Corta la pasta de hojaldre en cuadros del mismo tamaño, espolvorealos con azúcar glass y perforalos con un tenedor. Hórnealos hasta que estén dorados.",#imageLiteral(resourceName: "recipe")),
                                ("En una olla, coloca la crema la mantequilla y la mitad del azúcar. Abrir la vaina de vainilla y poner las semillas en la preparación. Tenerla a fuego medio hasta que comience a hervir.",#imageLiteral(resourceName: "recipe")),
                                ("En un bowl mezcla el restante del azúcar, las yemas, el harina de maíz y la leche. Mezclando perfectamente todo.",#imageLiteral(resourceName: "recipe")),
                                ("A la mezcla de las yemas, vertir un poco de la preparacion de la crema con vainilla, mover constantemente para evitar que el huevo se cuesa. Añadir poco a poco la crema, hasta obtener una mezcla espesa. Retirar del fuego y colocar en un recipiente para que se enfríe; es importante taparla con plástico adherente para evitar que se le haga costra.",#imageLiteral(resourceName: "recipe")),
                                ("Para el montaje en un refractario coloca una base de hojaldre, cubrela con la mezcla de vainilla, utilizando una manga pastelera. Repetir la base de hojaldre y la mezcla de vainilla hasta llegar a l tope del refractario.",#imageLiteral(resourceName: "recipe")),
                                ("En la parte de arriba agrega la crema para batir y rebanadas de mango. Decora con pistaches y almendras.",#imageLiteral(resourceName: "recipe")),
                                ("Disfrutar.",#imageLiteral(resourceName: "milHojasMango"))])
        
        self.recipes.append(recipe)
        
        recipe = Recipe(name: "Postré de Mango",
                        image: #imageLiteral(resourceName: "postreMango"),
                        time: 60,
                        difficulty: 3,
                        portion: 6,
                        ingredients: ["1 pieza de rebanadas de mango en almíbar en lata.",
                                      "3 piezas de hojaldre paquetes mililitros de leche",
                                      "100 gramos de azúcar glass para decorar",
                                      "200 gramos de crema para batir",
                                      "225 gramos de harina de maíz",
                                      "8 piezas de yema de huevo",
                                      "1 pieza de vaina de vainilla",
                                      "100 gramos de mantequilla",
                                      "40 gramos de pistache picados",
                                      "40 gramos de almendra tostada y en trozo"],
                        steps: [("Precalienta el horno a 180°C", #imageLiteral(resourceName: "recipe")),
                                ("Corta la pasta de hojaldre en cuadros del mismo tamaño, espolvorealos con azúcar glass y perforalos con un tenedor. Hórnealos hasta que estén dorados.",#imageLiteral(resourceName: "recipe")),
                                ("Para el montaje en un refractario coloca una base de hojaldre, cubrela con la mezcla de vainilla, utilizando una manga pastelera. Repetir la base de hojaldre y la mezcla de vainilla hasta llegar a l tope del refractario.",#imageLiteral(resourceName: "recipe")),
                                ("En la parte de arriba agrega la crema para batir y rebanadas de mango. Decora con pistaches y almendras.",#imageLiteral(resourceName: "recipe")),
                                ("Disfrutar.",#imageLiteral(resourceName: "postreMango"))])
        
        recipes.append(recipe)
        
        recipe = Recipe(name: "Rollitos de Melon con Jamón",
                        image: #imageLiteral(resourceName: "rollitosMelon"),
                        time: 60,
                        difficulty: 3,
                        portion: 6,
                        ingredients: ["1 pieza de rebanadas de mango en almíbar en lata.",
                                      "3 piezas de hojaldre paquetes mililitros de leche",
                                      "100 gramos de azúcar glass para decorar",
                                      "200 gramos de crema para batir",
                                      "225 gramos de harina de maíz",
                                      "8 piezas de yema de huevo",
                                      "1 pieza de vaina de vainilla",
                                      "100 gramos de mantequilla",
                                      "40 gramos de pistache picados",
                                      "40 gramos de almendra tostada y en trozo"],
                        steps: [("Precalienta el horno a 180°C", #imageLiteral(resourceName: "recipe")),
                                ("Corta la pasta de hojaldre en cuadros del mismo tamaño, espolvorealos con azúcar glass y perforalos con un tenedor. Hórnealos hasta que estén dorados.",#imageLiteral(resourceName: "recipe")),
                                ("Para el montaje en un refractario coloca una base de hojaldre, cubrela con la mezcla de vainilla, utilizando una manga pastelera. Repetir la base de hojaldre y la mezcla de vainilla hasta llegar a l tope del refractario.",#imageLiteral(resourceName: "recipe")),
                                ("En la parte de arriba agrega la crema para batir y rebanadas de mango. Decora con pistaches y almendras.",#imageLiteral(resourceName: "recipe")),
                                ("Disfrutar.",#imageLiteral(resourceName: "postreMango"))])
        
        recipes.append(recipe)
        
        recipe = Recipe(name: "Pizza con champiñones",
                        image: #imageLiteral(resourceName: "pizza"),
                        time: 60,
                        difficulty: 3,
                        portion: 6,
                        ingredients: ["1 pieza de rebanadas de mango en almíbar en lata.",
                                      "3 piezas de hojaldre paquetes mililitros de leche",
                                      "100 gramos de azúcar glass para decorar",
                                      "200 gramos de crema para batir",
                                      "225 gramos de harina de maíz",
                                      "8 piezas de yema de huevo",
                                      "1 pieza de vaina de vainilla",
                                      "100 gramos de mantequilla",
                                      "40 gramos de pistache picados",
                                      "40 gramos de almendra tostada y en trozo"],
                        steps: [("Precalienta el horno a 180°C", #imageLiteral(resourceName: "recipe")),
                                ("Corta la pasta de hojaldre en cuadros del mismo tamaño, espolvorealos con azúcar glass y perforalos con un tenedor. Hórnealos hasta que estén dorados.",#imageLiteral(resourceName: "recipe")),
                                ("Para el montaje en un refractario coloca una base de hojaldre, cubrela con la mezcla de vainilla, utilizando una manga pastelera. Repetir la base de hojaldre y la mezcla de vainilla hasta llegar a l tope del refractario.",#imageLiteral(resourceName: "recipe")),
                                ("En la parte de arriba agrega la crema para batir y rebanadas de mango. Decora con pistaches y almendras.",#imageLiteral(resourceName: "recipe")),
                                ("Disfrutar.",#imageLiteral(resourceName: "postreMango"))])
        
        recipes.append(recipe)
        
        print(recipes.count)
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  
    
    /*
     Function to prepare the next view and send recipes to another view
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // if usernameTextField.text == "sebas8632"{
        
        // if passwordTextField.text == "12345"{
        
        if segue.identifier == "logInSegue"{
            
            let destinationViewController = segue.destination as! myRecipesTableViewController
            
            destinationViewController.recipes = self.recipes
            
        }
        
        // }
        //  }
        
    }
 
    
    
    
    
    
}



