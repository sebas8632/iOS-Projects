//
//  CategoryCell.swift
//  pruebaRappi
//
//  Created by sebastian on 27/02/17.
//  Copyright © 2017 Juan Sebastián Florez Saavedra. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    // Variables
    
    @IBOutlet var imageCategory: UIImageView!
   
    @IBOutlet var categoryLabel: UILabel!
    
    
    
    
   }
