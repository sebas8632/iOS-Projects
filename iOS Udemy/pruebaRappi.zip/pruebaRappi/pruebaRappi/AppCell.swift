//
//  AppCell.swift
//  pruebaRappi
//
//  Created by sebastian on 24/02/17.
//  Copyright © 2017 Juan Sebastián Florez Saavedra. All rights reserved.
//

import UIKit

class AppCell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var appNameLabel: UILabel!
}
