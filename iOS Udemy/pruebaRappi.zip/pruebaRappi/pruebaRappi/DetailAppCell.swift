//
//  DetailAppCell.swift
//  pruebaRappi
//
//  Created by sebastian on 27/02/17.
//  Copyright © 2017 Juan Sebastián Florez Saavedra. All rights reserved.
//

import UIKit

class DetailAppCell: UITableViewCell {
   
    //Variables
    
    @IBOutlet var keyLabel: UILabel!
    @IBOutlet var valueLabel: UILabel!



}
