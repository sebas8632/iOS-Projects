//
//  MemoryCell.swift
//  GloryDays
//
//  Created by sebastian on 25/01/17.
//  Copyright © 2017 nhvm. All rights reserved.
//

import UIKit

class MemoryCell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
}
